# PWA Code & Tool Snippets


## App Shell


## Web Manifest

- sample manifest file
- placeholder icon images


## Feature Detection

- service worker
- push notifications
- backgrouind sync
- fetch
- promise


## Service Worker

- cache cleanup in activate event
- pre-cache in install event
- cache - falling back to network - cache network response

