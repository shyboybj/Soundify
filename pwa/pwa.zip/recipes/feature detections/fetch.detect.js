if (typeof fetch === "undefined" || fetch.toString().indexOf("[native code]") === -1) {

    //Load polyfill fetch.js

}