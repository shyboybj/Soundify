if (typeof Promise === "undefined" || Promise.toString().indexOf("[native code]") === -1) {

    //Load Polyfill: es6-promise.min.js

}
